package edu.sabanciuniv.operatingsystemsexample;

public class OperatingSys {

   private int id;
   private String name, history, rating, imagePath;

    public OperatingSys(int id, String name, String history, String rating, String imagePath) {
        this.id = id;
        this.name = name;
        this.history = history;
        this.rating = rating;
        this.imagePath = imagePath;
    }

    public OperatingSys() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}
