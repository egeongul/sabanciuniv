package edu.sabanciuniv.operatingsystemsexample;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.concurrent.ExecutorService;

public class commentsAdapter extends RecyclerView.Adapter<commentsAdapter.viewHolder>{

    private Context ctx;
    private List<comments> data;

    public commentsAdapter(Context ctx, List<comments> data){
        this.ctx = ctx;
        this.data = data;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View root= LayoutInflater.from(ctx).inflate(R.layout.news_row,parent,false);

        commentsAdapter.viewHolder holder = new commentsAdapter.viewHolder(root);
        holder.setIsRecyclable(false);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {
        holder.commentName.setText(data.get(holder.getAdapterPosition()).getName());
        holder.comment.setText(data.get(holder.getAdapterPosition()).getText());

        holder.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class viewHolder extends RecyclerView.ViewHolder{

        TextView commentName;
        TextView comment;
        ConstraintLayout row;

        public viewHolder(@NonNull View itemView) {
            super(itemView);

            commentName = itemView.findViewById(R.id.comment_name);
            comment = itemView.findViewById(R.id.comment);
            row = itemView.findViewById(R.id.comment_row);

        }
    }
}
