package edu.sabanciuniv.operatingsystemsexample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.ProgressBar;

import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    ProgressBar prg;
    RecyclerView recView;
    Button btnEcon, btnPolitics;

    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<news> data = (List<news>)msg.obj;
            OperatingSystemsAdapter adp = new OperatingSystemsAdapter(MainActivity2.this,data);
            recView.setAdapter(adp);
            recView.setVisibility(View.VISIBLE);
            prg.setVisibility(View.INVISIBLE);

            return true;
        }
    });


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_home_24);
        setTitle("Sports");


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnEcon = findViewById(R.id.button2);
        btnPolitics = findViewById(R.id.button4);
        prg = findViewById(R.id.progressBarList);
        recView = findViewById(R.id.recyclerViewList);
        recView.setLayoutManager(new LinearLayoutManager(this));
        prg.setVisibility(View.VISIBLE);
        recView.setVisibility(View.INVISIBLE);

        OpSysRepository repo = new OpSysRepository();
        repo.getAllData2(((OperatingSystemsApp) getApplication()).srv, dataHandler);


        AlphaAnimation buttonClick = new AlphaAnimation(2F, 0.8F); // to have a faded color when clicked
        btnEcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(i);
                view.startAnimation(buttonClick);
            }
        });

        btnPolitics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity2.this, MainActivity3.class);
                startActivity(i);
                view.startAnimation(buttonClick);
            }
        });

    }
}