package edu.sabanciuniv.operatingsystemsexample;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;

public class OpSysRepository {



    public void getAllData(ExecutorService srv, Handler uiHandler){

            srv.execute(()->{
                try {
                    URL url = new URL("http://10.3.0.14:8080/newsapp/getbycategoryid/1");
                    //URL url = new URL("http://10.3.0.14:8080/operatingsystemsapi/getall");
                    HttpURLConnection conn =(HttpURLConnection)url.openConnection();


                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder buffer = new StringBuilder();
                    String line = "";

                    while((line=reader.readLine())!=null){

                        buffer.append(line);

                    }

                    /*
                    JSONArray arr = new JSONArray(buffer.toString());
                    List<OperatingSys> data = new ArrayList<>();

                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject current = arr.getJSONObject(i);

                        OperatingSys opSys = new OperatingSys(current.getInt("id"),
                                current.getString("name"),
                                current.getString("history"),
                                current.getString("rating"),
                                current.getString("imagepath"));
                        data.add(opSys);

                    }
                    */



                    JSONObject obj = new JSONObject(buffer.toString());
                    List<news> data = new ArrayList<>();
                    if( obj.getInt("serviceMessageCode") == 1){
                        JSONArray arr = obj.getJSONArray("items");
                        for (int i = 0; i < arr.length(); i++){
                            JSONObject current = (JSONObject) arr.get(i);
                            news haber = new news(  current.getInt("id"),
                                                    current.getString("title"),
                                                    current.getString("text"),
                                                    current.getString("date"),
                                                    current.getString("image"),
                                                    current.getString("categoryName"));
                            data.add(haber);
                        }

                    }




                    Message msg = new Message();
                    msg.obj = data;
                    uiHandler.sendMessage(msg);



                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            });


    }

    public void getAllData2(ExecutorService srv, Handler uiHandler){

        srv.execute(()->{
            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getbycategoryid/2");
                //URL url = new URL("http://10.3.0.14:8080/operatingsystemsapi/getall");
                HttpURLConnection conn =(HttpURLConnection)url.openConnection();


                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder buffer = new StringBuilder();
                String line = "";

                while((line=reader.readLine())!=null){

                    buffer.append(line);

                }

                    /*
                    JSONArray arr = new JSONArray(buffer.toString());
                    List<OperatingSys> data = new ArrayList<>();

                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject current = arr.getJSONObject(i);

                        OperatingSys opSys = new OperatingSys(current.getInt("id"),
                                current.getString("name"),
                                current.getString("history"),
                                current.getString("rating"),
                                current.getString("imagepath"));
                        data.add(opSys);

                    }
                    */



                JSONObject obj = new JSONObject(buffer.toString());
                List<news> data = new ArrayList<>();
                if( obj.getInt("serviceMessageCode") == 1){
                    JSONArray arr = obj.getJSONArray("items");
                    for (int i = 0; i < arr.length(); i++){
                        JSONObject current = (JSONObject) arr.get(i);
                        news haber = new news(  current.getInt("id"),
                                current.getString("title"),
                                current.getString("text"),
                                current.getString("date"),
                                current.getString("image"),
                                current.getString("categoryName"));
                        data.add(haber);
                    }

                }




                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);



            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


        });


    }

    public void getAllData3(ExecutorService srv, Handler uiHandler){

        srv.execute(()->{
            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getbycategoryid/3");
                //URL url = new URL("http://10.3.0.14:8080/operatingsystemsapi/getall");
                HttpURLConnection conn =(HttpURLConnection)url.openConnection();


                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder buffer = new StringBuilder();
                String line = "";

                while((line=reader.readLine())!=null){

                    buffer.append(line);

                }

                    /*
                    JSONArray arr = new JSONArray(buffer.toString());
                    List<OperatingSys> data = new ArrayList<>();

                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject current = arr.getJSONObject(i);

                        OperatingSys opSys = new OperatingSys(current.getInt("id"),
                                current.getString("name"),
                                current.getString("history"),
                                current.getString("rating"),
                                current.getString("imagepath"));
                        data.add(opSys);

                    }
                    */



                JSONObject obj = new JSONObject(buffer.toString());
                List<news> data = new ArrayList<>();
                if( obj.getInt("serviceMessageCode") == 1){
                    JSONArray arr = obj.getJSONArray("items");
                    for (int i = 0; i < arr.length(); i++){
                        JSONObject current = (JSONObject) arr.get(i);
                        news haber = new news(  current.getInt("id"),
                                current.getString("title"),
                                current.getString("text"),
                                current.getString("date"),
                                current.getString("image"),
                                current.getString("categoryName"));
                        data.add(haber);
                    }

                }




                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);



            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


        });


    }



    public void getDataById(ExecutorService srv, Handler uiHandler,int id){


        srv.execute(()->{
            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getnewsbyid/" + String.valueOf(id));
                HttpURLConnection conn =(HttpURLConnection)url.openConnection();


                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder buffer = new StringBuilder();
                String line = "";

                while((line=reader.readLine())!=null){

                    buffer.append(line);

                }



                JSONObject current = new JSONObject(buffer.toString());
                JSONArray arr = current.getJSONArray("items");
                JSONObject current2 = (JSONObject) arr.get(0);
                news haber = new news(current2.getInt("id"),
                        current2.getString("title"),
                        current2.getString("text"),
                        current2.getString("date"),
                        current2.getString("image"),
                        current2.getString("categoryName"));


                Message msg = new Message();
                msg.obj = haber;
                uiHandler.sendMessage(msg);


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


        });

    }

    public void downloadImage(ExecutorService srv, Handler uiHandler,String path){
        srv.execute(()->{
            try {
                URL url = new URL(path);
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();

                Bitmap bitmap =  BitmapFactory.decodeStream(conn.getInputStream());

                Message msg = new Message();
                msg.obj = bitmap;
                uiHandler.sendMessage(msg);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        });
    }


    public void getCommentsById(ExecutorService srv, Handler uiHandler, int ID ){

        srv.execute(()->{
            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getcommentsbynewsid/" + String.valueOf(ID));
                HttpURLConnection conn =(HttpURLConnection)url.openConnection();


                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder buffer = new StringBuilder();
                String line = "";

                while((line=reader.readLine())!=null){

                    buffer.append(line);

                }



                JSONObject obj = new JSONObject(buffer.toString());
                List<comments> data = new ArrayList<>();
                if( obj.getInt("serviceMessageCode") == 1){
                    JSONArray arr = obj.getJSONArray("items");
                    for (int i = 0; i < arr.length(); i++){
                        JSONObject current = (JSONObject) arr.get(i);
                        comments yorum = new comments(  current.getInt("id"),
                                current.getInt("news_id"),
                                current.getString("text"),
                                current.getString("name"));
                        data.add(yorum);
                    }
                }




                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


        });


    }

    public void sendComment(ExecutorService srv , String name, String text, String id){

        srv.execute(()->{

            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/savecomment");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type","application/JSON");

                JSONObject outputData = new JSONObject();
                outputData.put("name", name);
                outputData.put("text", text);
                outputData.put("news_id", id);

                BufferedOutputStream writer = new BufferedOutputStream(conn.getOutputStream());
                writer.write(outputData.toString().getBytes(StandardCharsets.UTF_8));
                writer.flush();
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder buffer = new StringBuilder();
                String line = "";
                while((line = reader.readLine()) != null){
                    buffer.append(line);
                }

                conn.disconnect();



            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

        });


    }
}
