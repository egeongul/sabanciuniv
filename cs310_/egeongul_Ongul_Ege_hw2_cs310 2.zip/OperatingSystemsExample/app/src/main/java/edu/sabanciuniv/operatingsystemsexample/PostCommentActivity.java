package edu.sabanciuniv.operatingsystemsexample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class PostCommentActivity extends AppCompatActivity {

    TextView myName, myComment;
    Button btnPostComment;
    MaterialButton btnMaterial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_comment);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        setTitle("PostComment");

        myName = findViewById(R.id.commenterName);
        myComment = findViewById(R.id.commenterComment);
        btnMaterial = findViewById(R.id.materialButton);
        AlphaAnimation buttonClick = new AlphaAnimation(2F, 0.8F);

        btnMaterial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = myName.getText().toString();
                String comment = myComment.getText().toString();
                if(name.equals("")){
                    Toast.makeText(PostCommentActivity.this
                            , "Name cant be empty", Toast.LENGTH_LONG).show();
                }
                else if(name.equals("Your Name")){
                    Toast.makeText(PostCommentActivity.this
                            , "Name cant be empty", Toast.LENGTH_LONG).show();
                }
                else if(comment.equals("")){
                    Toast.makeText(PostCommentActivity.this
                            , "Comment cant be empty", Toast.LENGTH_LONG).show();
                }
                else if(comment.equals("Your Comments")){
                    Toast.makeText(PostCommentActivity.this
                            , "Comment cant be empty", Toast.LENGTH_LONG).show();
                }
                else{
                    view.startAnimation(buttonClick);
                    OpSysRepository repo = new OpSysRepository();
                    int id = getIntent().getIntExtra("ID", 1);
                    repo.sendComment(((OperatingSystemsApp) getApplication()).srv, name, comment, String.valueOf(id));
                    Toast.makeText(PostCommentActivity.this
                            , "Your comment has been saved", Toast.LENGTH_LONG).show();

                    Intent i = new Intent(PostCommentActivity.this, CommentsActivity.class);
                    i.putExtra("ID",id);
                    startActivity(i);
                }
            }
        });




    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return true;
    }
}