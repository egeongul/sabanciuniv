package edu.sabanciuniv.operatingsystemsexample;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class CommentsActivity extends AppCompatActivity {

    RecyclerView recView;
    Button btnComment;


    Handler dataHandler2 = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<comments> data = (List<comments>)msg.obj;
            commentsAdapter adp = new commentsAdapter(CommentsActivity.this,data);
            recView.setAdapter(adp);
            recView.setVisibility(View.VISIBLE);
            return true;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        /*
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_home_24);
         */
        setTitle("Comments");
        int id = getIntent().getIntExtra("ID", 1);

        recView = findViewById(R.id.commentRecView);
        recView.setLayoutManager(new LinearLayoutManager(this));
        recView.setVisibility(View.INVISIBLE);

        OpSysRepository repo = new OpSysRepository();
        repo.getCommentsById(((OperatingSystemsApp) getApplication()).srv, dataHandler2, id);

        btnComment = findViewById(R.id.btn1);

        btnComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CommentsActivity.this, PostCommentActivity.class);
                i.putExtra("ID", id);
                startActivity(i);
            }
        });



    }






}