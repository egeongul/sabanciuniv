package edu.sabanciuniv.operatingsystemsexample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.method.ScrollingMovementMethod;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;




public class ActivityDetails extends AppCompatActivity {

    ImageView imgDetails;
    TextView txtNameDetail;
    TextView txtHistoryDetail;
    TextView txtDateMy;
    Button btnComments;


    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {

            news haber = (news) msg.obj;

            txtNameDetail.setText(haber.getTitle());
            txtHistoryDetail.setText(haber.getText());
            String str = haber.getDate();
            String toBeAdded = str.substring(8,10) + "/" + str.substring(5,7) + "/" + str.substring(0,4);
            txtDateMy.setText(toBeAdded);

            OpSysRepository repo = new OpSysRepository();
            repo.downloadImage(((OperatingSystemsApp)getApplication()).srv,imgHandler, haber.getImagePath());

            return true;
        }
    });

    Handler imgHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {

            Bitmap img = (Bitmap) msg.obj;
            imgDetails.setImageBitmap(img);

            return true;
        }
    });


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        int id = getIntent().getIntExtra("id",1);
        String titleString = getIntent().getStringExtra("category");



        imgDetails =findViewById(R.id.imgDetails);
        txtNameDetail = findViewById(R.id.txtNameDetail);
        txtHistoryDetail = findViewById(R.id.textHist);
        txtDateMy = findViewById(R.id.dateTextView);
        btnComments = findViewById(R.id.btnComments);
        AlphaAnimation buttonClick = new AlphaAnimation(2F, 0.8F);
        btnComments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ActivityDetails.this, CommentsActivity.class);
                i.putExtra("ID",id);
                view.startAnimation(buttonClick);
                startActivity(i);
            }
        });

        setTitle(titleString);

        OpSysRepository repo = new OpSysRepository();
        repo.getDataById(((OperatingSystemsApp)getApplication()).srv,dataHandler,id);
        //txtHistoryDetail.setMovementMethod(new ScrollingMovementMethod());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==android.R.id.home){
            finish();
        }

        return true;
    }
}