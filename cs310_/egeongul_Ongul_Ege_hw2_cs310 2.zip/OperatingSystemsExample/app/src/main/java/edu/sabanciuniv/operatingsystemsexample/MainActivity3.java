package edu.sabanciuniv.operatingsystemsexample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.ProgressBar;

import java.util.List;

public class MainActivity3 extends AppCompatActivity {

    ProgressBar prg;
    RecyclerView recView;
    Button btnSport, btnEcon;
    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<news> data = (List<news>)msg.obj;
            OperatingSystemsAdapter adp = new OperatingSystemsAdapter(MainActivity3.this,data);
            recView.setAdapter(adp);
            recView.setVisibility(View.VISIBLE);
            prg.setVisibility(View.INVISIBLE);

            return true;
        }
    });


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_home_24);
        setTitle("Politics");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnEcon = findViewById(R.id.button2);
        btnSport = findViewById(R.id.button3);
        prg = findViewById(R.id.progressBarList);
        recView = findViewById(R.id.recyclerViewList);
        recView.setLayoutManager(new LinearLayoutManager(this));
        prg.setVisibility(View.VISIBLE);
        recView.setVisibility(View.INVISIBLE);

        OpSysRepository repo = new OpSysRepository();
        repo.getAllData3(((OperatingSystemsApp) getApplication()).srv, dataHandler);


        AlphaAnimation buttonClick = new AlphaAnimation(2F, 0.8F); // to have a faded color when clicked
        btnSport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity3.this, MainActivity2.class);
                startActivity(i);
                view.startAnimation(buttonClick);
            }
        });

        btnEcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity3.this, MainActivity.class);
                startActivity(i);
                view.startAnimation(buttonClick);
            }
        });

    }
}